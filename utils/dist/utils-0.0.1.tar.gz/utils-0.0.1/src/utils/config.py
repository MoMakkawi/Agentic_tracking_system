import os

class Config:
    DATA_URL = os.getenv("DATA_URL")
    SAVE_PATH = os.getenv("SAVE_PATH")
